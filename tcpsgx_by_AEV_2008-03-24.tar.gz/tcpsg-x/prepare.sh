#!/bin/sh


ARG1="$1"

if [ -z $ARG1 ]; then

	echo
	echo "Debe especificar un numero de instancia como parametro !!!"
	echo
	exit 1

fi


if [ -f /usr/sbin/tcpsg$ARG1 ]; then

	echo
	echo "Ya esta operativa una instancia de TCPSG$ARG1 en el sistema..."
	echo "Elija otro numero de instancia..."
	echo
	exit 1

fi

#######################################################################
####                         Main                                  ####
#######################################################################

echo
echo " - Generando nueva instancia de TCPSG..."
rm -fr TEMP 2> /dev/null
mkdir TEMP

cp tcpsgx.conf TEMP/tcpsg$ARG1.conf

cat Makefile | sed "s/tcpsgx/tcpsg$ARG1/g" > TEMP/Makefile

cat tcpsgx.c | sed "s/\/etc\/tcpsgx.conf/\/etc\/tcpsg$ARG1.conf/g" > TEMP/tcpsg$ARG1.c

cd TEMP

echo " - Compilando..."
make 1> /dev/null

echo " - Instalando archivos..."
cp tcpsg$ARG1.conf /etc
cp tcpsg$ARG1 /usr/sbin

echo " - Limpiando temporales..."
sleep 2
cd ..
rm -fr TEMP

echo " - Agregando a /etc/rc.local para su inicio con el sistema..."
printf "\n\n# Start TCPSG$ARG1\n/usr/sbin/tcpsg$ARG1\n\n" >> /etc/rc.local

echo " - Fin."
echo
echo
echo " ***  Ahora no olvide modificar los puertos de redireccion ***"
echo " ***  requeridos en /etc/tcpsg$ARG1.conf antes de ejecutar     ***"
echo
echo




